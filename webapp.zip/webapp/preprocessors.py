import pickle
import inflection
import pandas as pd
import numpy as np


class Pipeline(object):

    def __init__(self):
        self.home_path = ''

        # loads the rescaling
        self.numerical_vars_scaler = pickle.load(open(self.home_path + 'parameter/numerical_vars_scaler.pkl', 'rb'))

        # loads model
        self.model = pickle.load(open('model/model_people_analytics.pkl', 'rb'))

    def get_attribute_frequency(self, attribute):

        # creates a dictionary from value counts
        count_dict_attribute = attribute.value_counts().to_dict()

        # stores values as DataFrame
        df_count_attribute = pd.DataFrame(count_dict_attribute.items(), columns=['Value', 'Count'])

        # calculates the frequency for each value
        df_count_attribute['frequency'] = df_count_attribute['Count'] / df_count_attribute['Count'].sum()

        # gets a dictionary for the frequency
        frequency_attribute = df_count_attribute.set_index('Value').to_dict()['frequency']

        return frequency_attribute

    def get_encoded_frequencies(self, data_frame):

        # creates an empty DataFrame
        encoded_freq = pd.DataFrame()

        # creates columns for frequency
        for column in data_frame.columns:
            encoded_freq[column] = data_frame[column].map(self.get_attribute_frequency(data_frame[column]))

        return encoded_freq

    def make_rename_columns(self, input_data):

        # makes a copy
        data = input_data.copy()

        # stores the old column names
        cols_old = data.columns

        # snake case
        def snakecase(x): return inflection.underscore(x)

        # creates new columns from old columns in snakecase
        cols_new = list(map(snakecase, cols_old))

        # renames the old columns
        data.columns = cols_new

        return data

    def make_label_change(self, input_data):

        # makes a copy
        data = input_data.copy()

        # employee's education level
        data['education'] = data['education'].apply(lambda x: 'Bellow College' if x == 1
                                                    else 'College' if x == 2
                                                    else 'Bachelor' if x == 3
                                                    else 'Master' if x == 4
                                                    else 'Doctor')

        # how satisfied the employee is with the company's environment
        data['environment_satisfaction'] = data['environment_satisfaction'].apply(lambda x: 'Low' if x == 1
                                                                                  else 'Medium' if x == 2
                                                                                  else 'High' if x == 3
                                                                                  else 'Very High')

        # how involved the employee feels with his/her job
        data['job_involvement'] = data['job_involvement'].apply(lambda x: 'Low' if x == 1
                                                                else 'Medium' if x == 2
                                                                else 'High' if x == 3
                                                                else 'Very High')

        # employee's job level
        data['job_level'] = data['job_level'].apply(lambda x: 'Junior' if x == 1
                                                    else 'Mid' if x == 2
                                                    else 'Senior' if x == 3
                                                    else 'Manager' if x == 4
                                                    else 'Director')

        # how satisfied the employee feels with his/her job
        data['job_satisfaction'] = data['job_satisfaction'].apply(lambda x: 'Low' if x == 1
                                                                  else 'Medium' if x == 2
                                                                  else 'High' if x == 3
                                                                  else 'Very High')

        # employee's performance rating
        data['performance_rating'] = data['performance_rating'].apply(lambda x: 'Low' if x == 1
                                                                      else 'Good' if x == 2
                                                                      else 'Excellent' if x == 3
                                                                      else 'Outstanding')

        # how satisfied the employee feels with the relationship with his/her manager
        data['relationship_satisfaction'] = data['relationship_satisfaction'].apply(lambda x: 'Low' if x == 1
                                                                                    else 'Medium' if x == 2
                                                                                    else 'High' if x == 3
                                                                                    else 'Very High')

        # how the employee feels about his/her work life balance
        data['work_life_balance'] = data['work_life_balance'].apply(lambda x: 'Bad' if x == 1
                                                                    else 'Good' if x == 2
                                                                    else 'Better' if x == 3
                                                                    else 'Best')
        return data

    def make_data_prep(self, input_data):

        # makes a copy
        data = input_data.copy()

        # gets only numerical attributes
        num_attributes = data.select_dtypes(include=['int64'])

        # gets only binary attributes
        binary_attributes = data[['over_time', 'gender']]

        # gets only categorical attributes
        cat_attributes = data.select_dtypes(exclude=['int64'])

        # drops the target var and binary attribute
        cat_attributes.drop(['over_time', 'gender'], axis=1, inplace=True)

        # SCALING NUMERICAL VARS #
        # ---------------------- #

        # we need to scale the data because the range of variables vary a lot within them
        # treat the features equally
        scaled_numerical = self.numerical_vars_scaler.fit_transform(num_attributes)

        # gets the Data Frame version of numerical scaled for later manipulation
        df_scaled_numerical = pd.DataFrame(scaled_numerical)

        # renaming the columns of result Data Frame
        df_scaled_numerical.columns = num_attributes.columns

        # ENCODING BINARY VARS #
        # -------------------- #

        # creates an empty DataFrame
        df_binary_att_encoded = pd.DataFrame()

        # encondes over_time
        df_binary_att_encoded['over_time'] = binary_attributes['over_time'].apply(lambda x: 1 if x == 'Yes' else 0)

        # encondes gender
        df_binary_att_encoded['gender'] = binary_attributes['gender'].apply(lambda x: 1 if x == 'Male' else 0)

        # ENCODING CATEGORICAL VARS #
        # ------------------------- #

        # resets the index
        cat_attributes.reset_index(drop=True, inplace=True)

        # frequency encodes categorical vars
        cat_attr_freq_encoded = self.get_encoded_frequencies(cat_attributes)

        # joins scaled with encoded attributes
        data_prep = pd.concat([df_scaled_numerical, df_binary_att_encoded, cat_attr_freq_encoded], axis=1)

        return data_prep

    def transform(self, input_data):

        # makes a copy
        data = input_data.copy()

        # renames the columns to snakecase
        data_renamed_cols = self.make_rename_columns(data)

        # drops unused columns
        data_renamed_cols.drop(['over18', 'standard_hours', 'employee_count', 'employee_number'], axis=1, inplace=True)

        # changes data labels
        data_labels_changed = self.make_label_change(data_renamed_cols)

        # preps the data
        data_prep = self.make_data_prep(data_labels_changed)

        return data_prep

    def reorder_columns(self, input_data):

        # makes a copy
        data = input_data.copy()

        data = data[['employee_number', 'age', 'business_travel', 'daily_rate', 'department',
                     'distance_from_home', 'education', 'education_field', 'employee_count',
                     'environment_satisfaction', 'gender', 'hourly_rate',
                     'job_involvement', 'job_level', 'job_role', 'job_satisfaction',
                     'marital_status', 'monthly_income', 'monthly_rate',
                     'num_companies_worked', 'over18', 'over_time', 'percent_salary_hike',
                     'performance_rating', 'relationship_satisfaction', 'standard_hours',
                     'stock_option_level', 'total_working_years', 'training_times_last_year',
                     'work_life_balance', 'years_at_company', 'years_in_current_role',
                     'years_since_last_promotion', 'years_with_curr_manager']]
        return data

    def predict(self, input_data):

        # makes a copy
        data = input_data.copy()

        # creates a new Data Frame
        test_data = pd.DataFrame()

        # creates new column for comparison
        test_data['employee_number'] = data['employee_number'].reset_index(drop=True)

        # transforms the data: renames cols, scales and encodes
        transformed_data = self.transform(data)

        # predicts
        predictions = self.model.predict(transformed_data)

        # creates y_pred column
        test_data['y_pred'] = predictions

        # filters the ones who tend to leave
        df_tend_to_leave = test_data[test_data['y_pred'] == 1]

        # filters original data set to check more info about the employee
        filter_employees = data['employee_number'].isin(set(df_tend_to_leave['employee_number']))
        df_employees = data[filter_employees]

        # reorder de columns
        df_employees = self.reorder_columns(df_employees)

        return df_employees
